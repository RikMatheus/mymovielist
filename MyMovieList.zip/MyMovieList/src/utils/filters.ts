import { Movie } from '../interfaces/Movie'

export type SectionListProps = {
  title: string,
  data: Movie[]
}

export const topRatedMovies = (data: Movie[]): Movie[] => {
  return [...data].sort((a, b) => a.vote_average - b.vote_average).reverse().slice(0, 10)
}

export const mostRecentMovies = (data: Movie[]): Movie[] => {
  return [...data].sort((a, b) => new Date(a.release_date).getTime() - new Date(b.release_date).getTime()).slice(0, 10)
}

export const buildMovieList = (data: Movie[]): SectionListProps[] => {
  let list: SectionListProps[] = []

  list.push({
    title: "Mais bem classificados",
    data: topRatedMovies(data)
  })

  list.push({
    title: "Recentes",
    data: mostRecentMovies(data)
  })

  list.push({
    title: "Mais bem classificados",
    data: topRatedMovies(data)
  })

  list.push({
    title: "Recentes",
    data: mostRecentMovies(data)
  })

  list.push({
    title: "Mais bem classificados",
    data: topRatedMovies(data)
  })

  list.push({
    title: "Recentes",
    data: mostRecentMovies(data)
  })

  list.push({
    title: "Mais bem classificados",
    data: topRatedMovies(data)
  })

  list.push({
    title: "Recentes",
    data: mostRecentMovies(data)
  })

  return list
}