import React, { useEffect } from "react"
import { StyleSheet, Image } from "react-native"

const BASE_PATH = "https://image.tmdb.org/t/p/w200"

type ImageProps = {
  src: string
}

export default function MovieImage({ src, ...otherProps }: ImageProps) {
  useEffect(() => {
    console.log(`${BASE_PATH}${src}`)
  }, [])
  
  return (
    <Image
      source={{ uri: `${BASE_PATH}${src}` }}
      style={styles.image}
      resizeMode="cover"
    />
  )
}

const styles = StyleSheet.create({
  image: {
    width: 80,
    height: 120,
    backgroundColor: "#444",
  },
})
