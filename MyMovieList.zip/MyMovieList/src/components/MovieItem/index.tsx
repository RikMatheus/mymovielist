import React, { useEffect } from "react"
import { View, Text, TouchableOpacity } from "react-native"
import { Movie } from "../../interfaces/Movie"
import { FontAwesome } from '@expo/vector-icons'
import MovieImage from '../MovieImage'

import { styles } from "./styles"

type MovieItemProps = {
  item: Movie,
  onPress: () => void
}

export default function MovieItem({ item, onPress }: MovieItemProps) {
  return (
    <>
      {item && (
        <TouchableOpacity
          style={styles.container}
          onPress={onPress}
        >
          <MovieImage src={item.poster_path} />
          <View style={styles.informations}>
            <Text style={styles.title}>{item.title}</Text>
          </View>
          <View style={styles.average}>
            <View style={styles.icon}>
              <FontAwesome name="star" size={12} color="white" />
            </View>
            <Text style={styles.voteAverage}>{item.vote_average}</Text>
          </View>
        </TouchableOpacity>
      )}
    </>
  )
}
