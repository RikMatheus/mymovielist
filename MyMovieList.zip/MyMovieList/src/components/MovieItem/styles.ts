import { StyleSheet } from 'react-native'
import { theme } from '../../theme'

export const styles = StyleSheet.create({
  container: {
    width: 80,
    position: 'relative',
  },
  informations: {
    marginTop: 4,    
  },
  title: {
    color: theme.colors.text,
    fontSize: 12,
  },
  icon: {
    marginRight: 4,
  },
  voteAverage: {
    color: theme.colors.text,
    fontSize: 12,
  },
  average: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingVertical: 2,
    paddingHorizontal: 4,
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 10,
    backgroundColor: "#0002",
  }
})