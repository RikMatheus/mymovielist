import { StyleSheet } from 'react-native'
import { theme } from '../../theme'

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    overflow: 'scroll',
    backgroundColor: theme.colors.background,
  },
  title: {
    fontSize: 16,
    margin: 16,
    color: theme.colors.text,
    fontWeight: "700"
  }
})

export const modalStyles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  content: {
    flex: 1,
  },
  icon: {
    marginRight: 4,
  },
  title: {
    fontSize: 26,
    fontWeight: "700",
  },
  subtitle: {
    fontSize: 18,
  },
  overview: {
    fontSize: 14,
  },
  button: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#333",
    borderRadius: 8,
  },
  buttonText: {
    fontSize: 14,
    textAlign: "center",
    textTransform: "uppercase",
    color: "#fff",
    flex: 1,
    borderLeftWidth: 1,
    borderLeftColor: "#fff3"
  },
  buttonIcon: {
    marginRight: 16,
    paddingVertical: 8,
  },
  infos: {
    flexDirection: "row",
    marginBottom: 8,
    alignItems: "center"
  },
  actions: {

  }
})