import React, { useCallback, useEffect, useMemo, useRef, useState } from "react"
import {
  StatusBar,
  FlatList,
  SectionList,
  Text,
  TouchableOpacity,
  View,
} from "react-native"
import {
  BottomSheetModal,
  BottomSheetModalProvider,
} from "@gorhom/bottom-sheet"
import { FontAwesome } from "@expo/vector-icons"

import MovieItem from "../../components/MovieItem"
import data from "../../utils/mocks/data"
import { buildMovieList, SectionListProps } from "../../utils/filters"
import { Movie } from "../../interfaces/Movie"
import { styles, modalStyles } from "./styles"

export default function Home() {
  const [movies, setMovies] = useState<SectionListProps[]>([])
  const [selectedMovie, setSelectedMovie] = useState<Movie>()

  const bottomSheetModalRef = useRef<BottomSheetModal>(null)
  const snapPoints = useMemo(() => ["50%", "75%"], [])

  const handleModalOpen = useCallback(() => {
    bottomSheetModalRef.current?.present()
  }, [])

  const handleMovieDetails = (movie: Movie) => {
    setSelectedMovie(movie)
    handleModalOpen()
  }

  useEffect(() => {
    setMovies(buildMovieList(data))
  }, [])

  return (
    <>
      <StatusBar barStyle={"light-content"} translucent backgroundColor={"transparent"} />
      <BottomSheetModalProvider>
        <View style={styles.container}>
          <SectionList
            contentContainerStyle={{ paddingBottom: 16 }}
            stickySectionHeadersEnabled={false}
            sections={movies}
            renderSectionHeader={({ section }) => (
              <>
                <Text style={styles.title}>{section.title}</Text>
                <FlatList
                  data={section.data}
                  renderItem={({ item }) => (
                    <MovieItem
                      item={item}
                      onPress={() => handleMovieDetails(item)}
                    />
                  )}
                  ItemSeparatorComponent={() => (
                    <View style={{ marginRight: 8 }}></View>
                  )}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ paddingHorizontal: 16 }}
                />
              </>
            )}
            renderItem={({ item, section }) => {
              return null
            }}
          />
          <BottomSheetModal
            ref={bottomSheetModalRef}
            index={1}
            snapPoints={snapPoints}
          >
            {selectedMovie && <ModalContent movie={selectedMovie} />}
          </BottomSheetModal>
        </View>
      </BottomSheetModalProvider>
    </>
  )
}

type ModalContentProps = {
  movie: Movie
}

const ModalContent = ({ movie }: ModalContentProps) => {
  return (
    <>
      {movie && (
        <View style={modalStyles.container}>
          <View style={modalStyles.content}>
            <Text style={modalStyles.title}>{movie.title}</Text>
            <View style={modalStyles.infos}>
              <View style={modalStyles.icon}>
                <FontAwesome name="star" size={20} color="#333" />
              </View>
              <View>
                <Text style={modalStyles.subtitle}>
                  {movie.vote_average} ({movie.vote_count})
                </Text>
              </View>
            </View>
            <Text style={modalStyles.overview}>{movie.overview}</Text>
          </View>
          <View style={modalStyles.actions}>
            <TouchableOpacity style={modalStyles.button}>
              <View style={modalStyles.buttonIcon}>
                <FontAwesome name="heart-o" size={20} color="white" />
              </View>
              <Text style={modalStyles.buttonText}>Adicionar à lista</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </>
  )
}
