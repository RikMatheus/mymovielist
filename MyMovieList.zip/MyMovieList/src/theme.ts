export const theme = {
  colors: {
    background: "#333",
    text: "#eee",
  }
}