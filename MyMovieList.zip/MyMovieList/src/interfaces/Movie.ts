export interface Movie {
  adult: boolean,
  backdrop_path: string,
  poster_path: string,
  id: number,
  original_language: string,
  original_title: string,
  overview: string,
  title: string,
  vote_average: number,
  vote_count: number,
  release_date: string
}